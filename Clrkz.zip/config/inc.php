<?php die();

[globals]
AUTOLOAD="controller/;installation/"
UI="installation/"

 ?>